const menuToggle = document.querySelector("#menu-toggle");
const sidebar = document.querySelector("#sidebar");
const topNav = document.querySelector(".top-nav");
const searchForm = document.querySelector("#search-form");
const searchInput = document.querySelector("#search-input");
const searchStatus = document.querySelector("#search-status");

document.querySelector("#year").textContent = new Date().getFullYear();

menuToggle?.addEventListener("click", () => {
  const isOpen = menuToggle.getAttribute("aria-expanded") === "true";
  menuToggle.setAttribute("aria-expanded", String(!isOpen));
  sidebar?.classList.toggle("open", !isOpen);
  topNav?.classList.toggle("open", !isOpen);
  searchForm?.classList.toggle("open", !isOpen);
  menuToggle.setAttribute("aria-label", !isOpen ? "Fechar menu lateral" : "Abrir menu lateral");
});

document.querySelectorAll(".top-nav a, .side-link").forEach(link => {
  link.addEventListener("click", () => {
    document.querySelectorAll(".side-link").forEach(item => item.classList.remove("active"));
    const matching = document.querySelector(`.side-link[href="${link.getAttribute("href")}"]`);
    if (matching) matching.classList.add("active");
    if (window.innerWidth <= 800) {
      sidebar?.classList.remove("open");
      topNav?.classList.remove("open");
      searchForm?.classList.remove("open");
      menuToggle?.setAttribute("aria-expanded", "false");
    }
  });
});

searchForm?.addEventListener("submit", event => {
  event.preventDefault();
  document.querySelectorAll(".search-hit").forEach(item => item.classList.remove("search-hit"));
  const term = searchInput.value.trim().toLocaleLowerCase("pt-BR");
  if (!term) {
    searchStatus.textContent = "Digite um termo para pesquisar no assunto.";
    searchInput.focus();
    return;
  }
  const sections = [...document.querySelectorAll("main section")];
  const match = sections.find(section => section.innerText.toLocaleLowerCase("pt-BR").includes(term));
  if (match) {
    match.classList.add("search-hit");
    match.scrollIntoView({ behavior: "smooth", block: "start" });
    searchStatus.textContent = `Conteúdo encontrado para “${searchInput.value.trim()}”.`;
  } else {
    searchStatus.textContent = `Não encontrei “${searchInput.value.trim()}” neste assunto. Tente termos como capacitor, carga, RTC ou resistor.`;
  }
});

searchInput?.addEventListener("input", () => {
  if (!searchInput.value.trim()) {
    searchStatus.textContent = "";
    document.querySelectorAll(".search-hit").forEach(item => item.classList.remove("search-hit"));
  }
});
