# Portal Eletroeletrônica

Site estático simples com HTML, CSS e JavaScript.

## Estrutura
- `index.html`: estrutura e conteúdo do portal
- `css/style.css`: aparência e responsividade
- `js/main.js`: menu mobile, ano do rodapé e pesquisa no conteúdo

## Como abrir
Abra `index.html` no navegador. Não precisa instalar dependências nem iniciar servidor.

## Como adicionar novos assuntos
1. Crie uma nova seção dentro de `<main>` no `index.html`.
2. Dê à seção um `id` único.
3. Adicione um link com o mesmo `href` na navegação lateral.
4. Use as classes existentes (`content-section`, `section-heading`, `info-card`) para manter o padrão visual.

O assunto inicial foi organizado a partir do arquivo fornecido sobre circuitos RC e RTC. Revise o conteúdo técnico com o professor antes de publicar.
